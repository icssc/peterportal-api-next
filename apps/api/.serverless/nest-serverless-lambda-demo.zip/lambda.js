var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import express from 'express';
import { createServer, proxy } from 'aws-serverless-express';
import { eventContext } from 'aws-serverless-express/middleware';
import { Module } from "@nestjs/common";
import { NestFactory } from '@nestjs/core';
import { ExpressAdapter } from '@nestjs/platform-express';
//-----------------------------------------------------------------------------------
// START: module setup
//-----------------------------------------------------------------------------------
import { AdvancedModule } from "./template/advanced/advanced.module";
import { SimpleModule } from "./template/simple/simple.module";
let AppModule = class AppModule {
};
AppModule = __decorate([
    Module({
        imports: [SimpleModule, AdvancedModule],
    })
], AppModule);
//-----------------------------------------------------------------------------------
// END: module setup
//-----------------------------------------------------------------------------------
/**
 * NOTE: If you get ERR_CONTENT_DECODING_FAILED in your browser, this is likely
 * due to a compressed response (e.g. gzip) which has not been handled correctly
 * by aws-serverless-express and/or API Gateway.
 * Add the necessary MIME types to binaryMimeTypes below
 */
const binaryMimeTypes = [];
let cachedServer;
async function bootstrapServer() {
    if (!cachedServer) {
        const expressApp = express();
        const nestApp = await NestFactory.create(AppModule, new ExpressAdapter(expressApp));
        nestApp.use(eventContext());
        await nestApp.init();
        cachedServer = createServer(expressApp, undefined, binaryMimeTypes);
    }
    return cachedServer;
}
export const handler = async (event, context) => {
    cachedServer = await bootstrapServer();
    return proxy(cachedServer, event, context, 'PROMISE').promise;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vbGFtYmRhLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUNBLE9BQU8sT0FBTyxNQUFNLFNBQVMsQ0FBQTtBQUU3QixPQUFPLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQzdELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUNqRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDeEMsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUMzQyxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFFMUQscUZBQXFGO0FBQ3JGLHNCQUFzQjtBQUN0QixxRkFBcUY7QUFDckYsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUsvRCxJQUFNLFNBQVMsR0FBZixNQUFNLFNBQVM7Q0FBRyxDQUFBO0FBQVosU0FBUztJQUhkLE1BQU0sQ0FBQztRQUNOLE9BQU8sRUFBRSxDQUFDLFlBQVksRUFBRSxjQUFjLENBQUM7S0FDeEMsQ0FBQztHQUNJLFNBQVMsQ0FBRztBQUVsQixxRkFBcUY7QUFDckYsb0JBQW9CO0FBQ3BCLHFGQUFxRjtBQUVyRjs7Ozs7R0FLRztBQUNILE1BQU0sZUFBZSxHQUFhLEVBQUUsQ0FBQztBQUVyQyxJQUFJLFlBQW9CLENBQUM7QUFFekIsS0FBSyxVQUFVLGVBQWU7SUFDN0IsSUFBSSxDQUFDLFlBQVksRUFBRTtRQUNoQixNQUFNLFVBQVUsR0FBRyxPQUFPLEVBQUUsQ0FBQztRQUM3QixNQUFNLE9BQU8sR0FBRyxNQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7UUFDbkYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO1FBQzVCLE1BQU0sT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3JCLFlBQVksR0FBRyxZQUFZLENBQUMsVUFBVSxFQUFFLFNBQVMsRUFBRSxlQUFlLENBQUMsQ0FBQztLQUN0RTtJQUNELE9BQU8sWUFBWSxDQUFDO0FBQ3JCLENBQUM7QUFFRCxNQUFNLENBQUMsTUFBTSxPQUFPLEdBQVksS0FBSyxFQUFFLEtBQVUsRUFBRSxPQUFnQixFQUFFLEVBQUU7SUFDdEUsWUFBWSxHQUFHLE1BQU0sZUFBZSxFQUFFLENBQUM7SUFDdkMsT0FBTyxLQUFLLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQy9ELENBQUMsQ0FBQSJ9