/**
 * make sure all controllers and services are imported here
 */
export declare class SimpleModule {
}
//# sourceMappingURL=simple.module.d.ts.map