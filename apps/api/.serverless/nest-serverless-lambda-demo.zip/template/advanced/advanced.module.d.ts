/**
 * make sure all controllers and services are imported here
 */
export declare class AdvancedModule {
}
//# sourceMappingURL=advanced.module.d.ts.map